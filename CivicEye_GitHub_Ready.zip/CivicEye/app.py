from flask import Flask, jsonify, request, render_template, send_from_directory
from werkzeug.utils import secure_filename
from pathlib import Path
from datetime import datetime, timezone
import sqlite3, os, uuid

BASE = Path(__file__).resolve().parent
DB_PATH = BASE / "civiceye.db"
UPLOAD_DIR = BASE / "static" / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
ALLOWED = {"png", "jpg", "jpeg", "webp"}

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = str(UPLOAD_DIR)

SAMPLE_PROJECTS = [
    ("Neighbourhood road resurfacing", "Model Town · Ward 12", "₹18.5 lakh", 68, "On track", "Municipal works (sample)"),
    ("Community park renovation", "Green Avenue · Ward 8", "₹9.2 lakh", 35, "Needs review", "Parks department (sample)"),
    ("Streetlight replacement drive", "Shahpur Road · Ward 4", "₹6.8 lakh", 82, "On track", "Electrical division (sample)"),
    ("Drainage improvement work", "New Colony · Ward 15", "₹24 lakh", 20, "Delayed", "Public works (sample)"),
    ("Public school toilet upgrade", "Village Centre · Ward 3", "₹7.4 lakh", 55, "On track", "Education works (sample)"),
    ("Bus stop accessibility upgrade", "Main Bazaar · Ward 6", "₹4.1 lakh", 40, "Needs review", "Transport works (sample)")
]

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS projects(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, area TEXT NOT NULL,
            budget TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'On track', agency TEXT NOT NULL,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL)""")
        con.execute("""CREATE TABLE IF NOT EXISTS reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER NOT NULL,
            category TEXT NOT NULL, location TEXT NOT NULL, details TEXT NOT NULL,
            photo TEXT, status TEXT NOT NULL DEFAULT 'Pending review',
            created_at TEXT NOT NULL, FOREIGN KEY(project_id) REFERENCES projects(id))""")
        count = con.execute("SELECT COUNT(*) FROM projects").fetchone()[0]
        if count == 0:
            now = datetime.now(timezone.utc).isoformat()
            for p in SAMPLE_PROJECTS:
                con.execute("""INSERT INTO projects(name,area,budget,progress,status,agency,created_at,updated_at)
                    VALUES(?,?,?,?,?,?,?,?)""", (*p, now, now))
            # clearly labelled sample observations
            samples = [
                (2,"Possible delay","Green Avenue park entrance","Work area appeared unchanged in two visits this week."),
                (4,"Progress update","New Colony, lane 3","Drain cover installation observed on the eastern side."),
                (1,"Progress update","Model Town market crossing","Fresh resurfacing visible near the crossing.")
            ]
            for r in samples:
                con.execute("""INSERT INTO reports(project_id,category,location,details,created_at)
                    VALUES(?,?,?,?,?)""", (*r, now))

def project_dict(row):
    d = dict(row)
    d["report_count"] = d.pop("reports", 0)
    return d

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/api/projects")
def get_projects():
    q = request.args.get("q", "").strip().lower()
    status = request.args.get("status", "all")
    with db() as con:
        rows = con.execute("""SELECT p.*, COUNT(r.id) AS reports
            FROM projects p LEFT JOIN reports r ON r.project_id=p.id
            GROUP BY p.id ORDER BY p.id""").fetchall()
    items = [project_dict(r) for r in rows]
    if q:
        items = [p for p in items if q in (p["name"]+" "+p["area"]).lower()]
    if status != "all":
        items = [p for p in items if p["status"] == status]
    return jsonify(items)

@app.get("/api/stats")
def stats():
    with db() as con:
        projects = con.execute("SELECT COUNT(*) FROM projects").fetchone()[0]
        reports = con.execute("SELECT COUNT(*) FROM reports").fetchone()[0]
        pending = con.execute("SELECT COUNT(*) FROM reports WHERE status='Pending review'").fetchone()[0]
        review = con.execute("SELECT COUNT(*) FROM projects WHERE status='Needs review'").fetchone()[0]
    return jsonify({"projects":projects, "reports":reports, "pending":pending, "review":review})

@app.get("/api/reports")
def get_reports():
    with db() as con:
        rows = con.execute("""SELECT r.*, p.name AS project_name FROM reports r
            JOIN projects p ON p.id=r.project_id ORDER BY r.id DESC LIMIT 20""").fetchall()
    return jsonify([dict(r) for r in rows])

@app.post("/api/reports")
def create_report():
    project_id = request.form.get("project_id", type=int)
    category = (request.form.get("category") or "").strip()
    location = (request.form.get("location") or "").strip()
    details = (request.form.get("details") or "").strip()
    if not project_id or not category or not location or not details:
        return jsonify({"error":"Please complete all required fields."}), 400
    if len(details) > 500 or len(location) > 160:
        return jsonify({"error":"Please shorten the report details or location."}), 400
    photo_name = None
    photo = request.files.get("photo")
    if photo and photo.filename:
        filename = secure_filename(photo.filename)
        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if ext not in ALLOWED:
            return jsonify({"error":"Photo must be PNG, JPG, JPEG or WEBP."}), 400
        photo_name = f"{uuid.uuid4().hex}.{ext}"
        photo.save(UPLOAD_DIR / photo_name)
    now = datetime.now(timezone.utc).isoformat()
    with db() as con:
        exists = con.execute("SELECT id FROM projects WHERE id=?", (project_id,)).fetchone()
        if not exists:
            return jsonify({"error":"Selected project was not found."}), 404
        con.execute("""INSERT INTO reports(project_id,category,location,details,photo,created_at)
            VALUES(?,?,?,?,?,?)""", (project_id,category,location,details,photo_name,now))
        if category in ("Possible delay", "Work quality concern"):
            con.execute("UPDATE projects SET status='Needs review', updated_at=? WHERE id=?", (now,project_id))
        report_id = con.execute("SELECT last_insert_rowid()").fetchone()[0]
    return jsonify({"ok":True,"id":report_id,"message":"Report submitted. It is pending human review."}), 201

@app.post("/api/reports/<int:report_id>/review")
def review_report(report_id):
    # Demo moderation endpoint. Add authentication/roles before public deployment.
    payload = request.get_json(silent=True) or {}
    new_status = payload.get("status")
    if new_status not in ("Verified observation", "Needs more information", "Closed"):
        return jsonify({"error":"Invalid review status."}), 400
    with db() as con:
        cur = con.execute("UPDATE reports SET status=? WHERE id=?", (new_status, report_id))
        if cur.rowcount == 0:
            return jsonify({"error":"Report not found."}), 404
    return jsonify({"ok":True,"status":new_status})

@app.get("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(UPLOAD_DIR, filename)

@app.errorhandler(413)
def too_large(_):
    return jsonify({"error":"Photo is too large. Maximum size is 5 MB."}), 413

init_db()  # Initialize the SQLite schema when imported by Gunicorn or run locally.

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
