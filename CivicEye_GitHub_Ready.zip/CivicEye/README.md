# CivicEye — Full Working MVP

A locally runnable full-stack hackathon prototype using Flask + SQLite.

## Features
- Flask backend and SQLite database (persists after refresh/restart)
- Projects dashboard with search and status filters
- Live dashboard statistics from the database
- Citizen report submission through API
- Optional photo uploads (PNG/JPG/JPEG/WEBP, max 5 MB)
- New delay/quality reports flag a project for human review
- Recent reports feed
- OpenStreetMap + Leaflet map (requires internet to load map tiles)

## Run on Windows
1. Install Python 3.10 or newer.
2. Extract this ZIP.
3. Open Command Prompt in the extracted `CivicEye_Full_Working_MVP` folder.
4. Run:
   ```bash
   py -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   python app.py
   ```
5. Open `http://127.0.0.1:5000` in your browser.

## Run on macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Then open `http://127.0.0.1:5000`.

## Important
- Seed project data is fictional. It is only for demonstration.
- This is a hackathon MVP, not production-ready government software.
- The review endpoint currently has no authentication. Do not expose it publicly as-is.
- Before public deployment, add user accounts, admin/verifier roles, CSRF protection, rate limiting, stronger file validation, audit logs, privacy/consent flows, backups, and secure hosting.
- Reports are allegations/observations until independently checked. Never label a person or organisation corrupt based only on an AI score or an unverified citizen report.
- Map pins are illustrative sample coordinates around Jalandhar, not actual project sites.


## Map search and area labels (added)
- Search for a city, neighbourhood, address, or landmark using the map search box.
- The map pans/zooms to the matching result.
- The area label updates after map movement or zoom, using OpenStreetMap's Nominatim reverse-geocoding service.
- This feature requires internet access. Search results and area labels are best-effort and may be unavailable if the public geocoding service is rate-limited.


## Render deployment preparation
This folder includes `render.yaml` and Gunicorn configuration for a Render web service.
- Push the project folder to a GitHub repository.
- In Render, choose New > Blueprint and connect the repository, or create a Web Service manually.
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`
- After deployment, add both purchased domains under the service's Settings > Custom Domains.
- Configure DNS exactly as Render instructs, then verify each hostname.

**Persistence warning:** The current MVP stores data and uploaded photos on the local filesystem. On Render's free service, local files can be lost when the service restarts or redeploys. Before collecting real public reports, migrate to managed PostgreSQL and object storage or a properly configured persistent disk. Do not treat this demo as production-ready without authentication, authorization, moderation, privacy controls, backups, and security review.
